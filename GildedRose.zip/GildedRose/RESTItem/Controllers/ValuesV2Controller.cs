﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GildedRose.Models;
using GildedRose.Services;
namespace GildedRose.Controllers
{
    public class ValuesV2Controller : ApiController
    {
        private ItemRepository itemRepository;
        public ValuesV2Controller()
        {
            this.itemRepository = new ItemRepository();
        }

        // GET api/values
        public IEnumerable<ItemV2> Get()
        {
            return itemRepository.GetAllItems();
        }

        // GET api/values/5
        public ItemV2 Get(int id)
        {
            List<ItemV2> ItemList = itemRepository.GetAllItems();
            for (int i = 0; i < ItemList.Count; i++)
            {
                if (ItemList[i].Id == id)
                    return ItemList[i];
            }
            return null;
        }

        // GET api/values/Buy/id/quantity
        [HttpGet]
        public String Buy(int id, int quantity)
        {

            //authenticate
            var re = Request;
            var headers = re.Headers;
            string username="";
            string password="";
            if (headers.Contains("username"))
            {
                username = headers.GetValues("username").First();
            }
            else
            {
                return "Authentication failed";
            }
            if (headers.Contains("password"))
            {
                password = headers.GetValues("password").First();
            }
            else
            {
                return "Authentication failed";
            }
            if (!Validate(username, password))
            {
                return "Authentication failed";
            }
            List<ItemV2> itemList = itemRepository.GetAllItems();
            for (int i = 0; i < itemList.Count; i++)
            {
                if (itemList[i].Id == id)
                {
                    if (itemList[i].ItemCount >= quantity)
                    {

                        itemList[i].ItemCount = itemList[i].ItemCount - quantity;
                        return "Price is: " + (itemList[i].Price * quantity).ToString("N2") +
                            " / Remaining Quantity is " + itemList[i].ItemCount;
                    }
                    else
                    {
                        return $"Not sufficient quantity. Available quantity is: {itemList[i].ItemCount}";
                    }
                }
            }
            return "No data found for given id";
        }

        // POST api/values
        [HttpPost, ActionName("AddItem")]
        public String Post([FromBody]ItemV2 item)
        {
            return this.itemRepository.saveItem(item);
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
        //mock user and password to be sent in header
        public bool Validate(string username, string password)
        {
            return username.Equals("test", StringComparison.OrdinalIgnoreCase)
                    && password == "test";

        }
    }
}