﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GildedRose.Models;

namespace GildedRose.Services
{
    public class ItemRepository
    {
        //cache key
        private const string CacheKey = "ItemStore";
        public ItemRepository()
        {
            var ctx = HttpContext.Current;
            if (ctx != null)
            {
                if (ctx.Cache[CacheKey] == null)
                {
                    //create a mock database
                    ctx.Cache[CacheKey] = ItemV2Database();
                }
            }
        }
        public List<ItemV2> GetAllItems()
        {
            var ctx = HttpContext.Current;
            if (ctx != null)
            {
                return (List<ItemV2>)ctx.Cache[CacheKey];
            }
            return null;
        }

        //save in database
        public string saveItem(ItemV2 item)
        {
            var ctx = HttpContext.Current;

            if (ctx != null)
            {
                try
                {
                    List<ItemV2> itemList = (List<ItemV2>)ctx.Cache[CacheKey];
                    if (exists(item.Id, itemList))
                    {
                        return "Item with given id already exists";
                    }
                    itemList.Add(item);
                    ctx.Cache[CacheKey] = itemList;
                    return "Successfully Added";

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    return ex.ToString();
                }
            }

            return "Database does not exists!";
        }

        //helper method to create mock database
        public List<ItemV2> ItemV2Database()
        {
            //create a mock database
            List<ItemV2> itemList = new List<ItemV2>();
            for (int i = 1; i < 11; i++)
            {
                var item = new ItemV2
                {
                    Id = i,
                    Name = "Item  " + i,
                    Description = "Item Description " + i,
                    Price = i + 24,
                    ItemCount = i + 1
                };
                itemList.Add(item);
            }
            return itemList;
        }

        /**
         * helper method to check if item exists with given id
         */
        private Boolean exists(int id, List<ItemV2> itemList)
        {
            for (int i = 0; i < itemList.Count; i++)
            {
                if (itemList[i].Id == id)
                {
                    return true;
                }
            }
            return false;
        }
    }
}